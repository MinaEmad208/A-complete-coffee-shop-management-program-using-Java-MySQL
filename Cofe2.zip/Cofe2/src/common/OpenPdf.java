package common;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.IOException;

public class OpenPdf {
    public static void openById(String id) {

        // إنشاء فولدر على C لو مش موجود
   ;String dirPath = "C:\\Bills";

        File dir = new File(dirPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        // مسار الملف
        String filePath = dirPath + "\\" + id + ".pdf";
        File file = new File(filePath);

        if (file.exists()) {
            try {
                Runtime.getRuntime().exec(new String[]{
                    "rundll32", "url.dll,FileProtocolHandler", filePath
                });
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "حدث خطأ أثناء فتح الملف: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "الملف غير موجود: " + filePath);
        }
    }
}
