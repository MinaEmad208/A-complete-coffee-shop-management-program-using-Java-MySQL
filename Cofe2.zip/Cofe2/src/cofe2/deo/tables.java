package cofe2.deo;

import javax.swing.JOptionPane;

public class tables {

    public static void main(String[] args) {
        // استعلام لإنشاء جدول المستخدم
        try {
            String userTable = "CREATE TABLE IF NOT EXISTS user ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, "
                    + "name VARCHAR(200), "
                    + "email VARCHAR(200) UNIQUE, "
                    + "mobileNumber VARCHAR(200), "
                    + "address VARCHAR(200), "
                    + "password VARCHAR(200), "
                    + "securityQuestion VARCHAR(200), "
                    + "answer VARCHAR(200), "
                    + "status VARCHAR(200))";

            // إزالة علامة الاستفهام من القيم المدخلة
            String adminDetails = "INSERT INTO user(name,email,mobileNumber,address,password,securityQuestion,answer,status)"
                  + " VALUES('emad','moon@gmail.com','12345678901','mina','mina','emad','mina','mina')";
String categoryTable = "create table category (id int AUTO_INCREMENT primary key, categoryName VARCHAR(200))";
String productTable = "create table product( id int AUTO_INCREMENT primary key , name VARCHAR(200),category VARCHAR(200),price VARCHAR(200))";
String billTable = "create table bill (id int primary key, categoryName VARCHAR(200),mobileNumber VARCHAR(200),email VARCHAR(200),date VARCHAR(50),total VARCHAR(200),createdBy VARCHAR(200))";

         DbOperations.setDataOrDelete(userTable, "User Table Created Successfully");
           DbOperations.setDataOrDelete(adminDetails, "Admin Details Added Successfully");
            DbOperations.setDataOrDelete(categoryTable, "Category Table Created Successfully");
            DbOperations.setDataOrDelete(productTable, "product Table Created Successfully");
 DbOperations.setDataOrDelete(billTable, "Bill Table Created Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
