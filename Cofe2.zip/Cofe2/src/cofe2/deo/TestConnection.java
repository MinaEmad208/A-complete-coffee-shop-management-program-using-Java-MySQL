/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofe2.deo;

import java.sql.Connection;

/**
 *
 * @author Mina Emad
 */
public class TestConnection {
     public static void main(String[] args) {
        Connection con = ConnectionProvder.getCon();
        if (con != null) {
            System.out.println("Connection Successful!");
        } else {
            System.out.println("Connection Failed!");
        }
    }
}
    

