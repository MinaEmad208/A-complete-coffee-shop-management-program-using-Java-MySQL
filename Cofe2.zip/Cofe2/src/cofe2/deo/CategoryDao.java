/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofe2.deo;

import cofe2.model.Category;
import com.mysql.cj.xdevapi.Result;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.*;

/**
 *
 * @author Mina Emad
 */
public class CategoryDao {

    public static void save(Category category) {
        String query = "insert into category (categoryName) values('" + category.getName() + "')";
        DbOperations.setDataOrDelete(query, "Category Added Successfully");
    }

    public static ArrayList<Category> getAllRecords() {
        ArrayList<Category> arrayList = new ArrayList<>();
        try {
            ResultSet rs = DbOperations.getData("select * from category");
            while (rs.next()) {
                Category category = new Category();
                category.setId(rs.getInt("id"));
                category.setName(rs.getString("categoryName"));
                arrayList.add(category);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;
    }

    public static void delate(String id) {
        String query = "delete from  category where id = '" + id + "'";
        DbOperations.setDataOrDelete(query, "category Delated Successfully");
    }
}
