package cofe2.deo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DbOperations {

    public static void setDataOrDelete(String Query, String msg) {
        try {
            // الحصول على الاتصال من ConnectionProvder
            Connection con = ConnectionProvder.getCon();
            Statement st = con.createStatement();
            
            // تنفيذ الاستعلام
            st.executeUpdate(Query);

            // عرض رسالة إذا لم تكن الرسالة فارغة
            if (!msg.equals("")) 
                JOptionPane.showMessageDialog(null, msg);
            
        } catch (Exception e) {
            // عرض رسالة خطأ عند حدوث استثناء
            JOptionPane.showMessageDialog(null, e , "Massage" , JOptionPane.ERROR_MESSAGE);
        }
    }
    public static ResultSet getData(String query){
 try{
 Connection con = ConnectionProvder.getCon();
 Statement st = con.createStatement();
 ResultSet rs = st.executeQuery(query);
 return rs;
 }
 catch(Exception e){            JOptionPane.showMessageDialog(null, e , "Massage" , JOptionPane.ERROR_MESSAGE);
 return null;

 
 }
    }

    static void setDataOrDelete(ResultSet query, String status_Change_Successfully) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
