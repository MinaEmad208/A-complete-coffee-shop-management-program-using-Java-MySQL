package cofe2.deo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvder {

    public static Connection getCon() {
        Connection con = null;
        try {
            // إعداد معلومات الاتصال
            String url = "jdbc:mysql://localhost:3306/cms?useSSL=false&allowPublicKeyRetrieval=true";
            String user = "root"; // اسم المستخدم
            String password = "new_password"; // كلمة المرور

            // تحميل سائق MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // إنشاء الاتصال
            con = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}